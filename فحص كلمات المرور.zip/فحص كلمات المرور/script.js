// script.js
document.getElementById('password').addEventListener('input', function() {
    const password = this.value;
    const strengthMessage = document.getElementById('strength-message');
    const strength = getPasswordStrength(password);

    strengthMessage.textContent = strength.message;
    strengthMessage.style.color = strength.color;
});

document.getElementById('reset-btn').addEventListener('click', function() {
    document.getElementById('password').value = '';
    document.getElementById('strength-message').textContent = '';
});

document.getElementById('subscribe-btn').addEventListener('click', function() {
    const isSubscribed = confirm("هل أنت مشترك في قناتنا على اليوتيوب؟");
    
    if (isSubscribed) {
        alert("أنت مشترك معنا، شكراً لكم! 🙏");
    } else {
        window.location.href = 'https://www.youtube.com/channel/UCtlNO91izT4z1brWh6WV3xQ';
    }
});

function getPasswordStrength(password) {
    let strength = {
        message: 'ضعيفة جداً 😢',
        color: 'red'
    };

    if (password.length > 8) {
        strength.message = 'جيدة 😊';
        strength.color = 'orange';
    }

    if (password.length > 12 && /[A-Z]/.test(password) && /[0-9]/.test(password) && /[!@#$%^&*]/.test(password)) {
        strength.message = 'قوية جداً 🚀😎';
        strength.color = 'green';
    }

    return strength;
}
